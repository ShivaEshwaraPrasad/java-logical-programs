package com.bitlabs.Arogya;

public interface DaoInterface {
	//public void ArogyapatientRegistration(Arogyapatient p);
	   //public void viewAllArogyapatient();
	   //public void searchArogyapatientById(int id);
	   //public void deleteArogyapatientById(int id);
	    //public void searchArogyapatientByCity(String city);
	    //public void searchArogyapatientByAgeGroup(int start,int end);
	    
	}


