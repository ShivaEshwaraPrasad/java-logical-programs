package com.bitlabs.Arogya;
public class App 
{
    public static void main( String[] args )
    {
    	 DaoInterface dao=new Daoimpl();
    	    Arogyapatient p=new Arogyapatient();
    	 
    	    p.setId(102);
    	    p.setAge(25);
    	    p.setName("Rakesh");
    	    p.setGender("male");
    	    p.setCity("Hyderabad");
    	    p.setAddress("2-404,Hyderabad");
    	    p.setGuardian_name("Bhanu");
    	    p.setGuardian_address("2-43");
    	    p.setDateOfAdmission("1992/08/22");
    	    p.setAadhar_Card_number(12345);
    	    p.setContact_number(961892);
    	    p.setGuardian_contactNumber(7702362);
    	    
    	    //dao.ArogyapatientRegistration(p);
    	   
    	    
    	    //dao.viewAllArogyapatient();
    	    
    	    //dao.searchArogyapatientById(101);
    	    
    	    //dao.deleteArogyapatientById(102);
    	    
    	    //dao.searchArogyapatientByCity("guntur");
    	    
    	    //dao.searchArogyapatientByAgeGroup(18, 55);
    	    
    	}

    	}
